export class Button {
  name: string;
}
