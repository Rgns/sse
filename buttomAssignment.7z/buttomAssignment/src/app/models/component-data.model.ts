export class ComponentData {
  id: string;
  name: string;
  show: boolean;
}
